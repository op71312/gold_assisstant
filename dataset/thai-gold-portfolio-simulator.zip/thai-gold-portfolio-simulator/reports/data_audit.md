# Data Audit Report

Input file: `/home/z/my-project/thai-gold-portfolio-simulator/dataset/gold_data_raw.csv` (sha256 `f5f707922a989ae8...`) - original preserved unmodified.

- Announcement rows: **23,385** (all with valid two-sided bar quotes: 23,385)
- Period: **2006-05-01 09:30:00 .. 2026-10-22 17:06:00**
- Daily rows after selection policy `last_valid_of_day`: **5,933**
- Calendar days with a valid quote: 5,933 of 7,480 (missing 1,547 days; weekends and GTA non-publication days are expected)
- Missing weekday blocks (incl. source gaps):
  - 2013-02-25 .. 2013-03-29 (22 weekdays)
  - 2016-08-01 .. 2016-12-05 (89 weekdays)
  - 2017-08-01 .. 2017-12-15 (99 weekdays)
  - 2018-01-01 .. 2018-01-15 (11 weekdays)
  - 2021-05-03 .. 2021-05-27 (19 weekdays)
  - 2025-07-01 .. 2025-07-16 (12 weekdays)
  - 2026-09-01 .. 2026-10-14 (26 weekdays)

## Price semantics
Columns follow the published GTA convention: `รับซื้อ` (bar_buy) = dealer buys = customer SELL price; `ขายออก` (bar_sell / ornament_sell) = dealer sells = customer BUY price. Liquidation valuation uses the customer SELL side. Units: THB per baht-weight (15.244 g, 96.5% purity). The historical ornament buy-back quote is not present in the source archive and is modeled (assumption A04).

## Quality checks
- Invalid/nonpositive bar buy: 0, bar sell: 0, ornament sell: 0
- Exact duplicate (timestamp,seq) rows: 17 (none removed; daily selection policy picks the authoritative quote per day)
- Rows sharing a timestamp: 52
- Announcements per date: mean 3.94, max 106
- Share of announcements with nonzero change: 93.9%
- Bar buy-sell spread (THB/baht-weight): mean 119, p5 100, p95 200
- Ornament sell minus bar sell (wage proxy): mean 570 THB/baht-weight
- Negative bar spreads: 0 (flagged, not removed)

## Selection-policy sensitivity
- Alternative policy `first_valid_of_day`: correlation of daily bar returns 0.8034; annualized vol 13.5% (primary) vs 13.5% (alt).

## Coverage by year
|   year |   valid_quote_days | first_quote_date    | last_quote_date     |   bar_sell_min |   bar_sell_max |   bar_sell_year_end |   bar_spread_mean | is_partial_year   |
|-------:|-------------------:|:--------------------|:--------------------|---------------:|---------------:|--------------------:|------------------:|:------------------|
|   2006 |                201 | 2006-05-01 00:00:00 | 2006-12-30 00:00:00 |          10150 |          12900 |               10850 |           100     | True              |
|   2007 |                299 | 2007-01-03 00:00:00 | 2007-12-29 00:00:00 |          10450 |          13400 |               13300 |           100     | False             |
|   2008 |                298 | 2008-01-03 00:00:00 | 2008-12-30 00:00:00 |          12200 |          15450 |               14000 |           100     | False             |
|   2009 |                297 | 2009-01-03 00:00:00 | 2009-12-30 00:00:00 |          13550 |          19150 |               17350 |           100     | False             |
|   2010 |                299 | 2010-01-04 00:00:00 | 2010-12-30 00:00:00 |          16850 |          20150 |               20150 |           100     | False             |
|   2011 |                301 | 2011-01-03 00:00:00 | 2011-12-30 00:00:00 |          19500 |          26850 |               23500 |           100     | False             |
|   2012 |                296 | 2012-01-03 00:00:00 | 2012-12-29 00:00:00 |          23050 |          25900 |               24100 |           100     | False             |
|   2013 |                273 | 2013-01-02 00:00:00 | 2013-12-30 00:00:00 |          17850 |          24300 |               18800 |           100     | False             |
|   2014 |                300 | 2014-01-02 00:00:00 | 2014-12-30 00:00:00 |          17850 |          21100 |               18550 |           100     | False             |
|   2015 |                298 | 2015-01-02 00:00:00 | 2015-12-30 00:00:00 |          17950 |          20100 |               18300 |           100     | False             |
|   2016 |                198 | 2016-01-02 00:00:00 | 2016-12-30 00:00:00 |          18200 |          22800 |               19750 |           100     | False             |
|   2017 |                188 | 2017-01-03 00:00:00 | 2017-12-30 00:00:00 |          19400 |          20950 |               20100 |           100     | False             |
|   2018 |                300 | 2018-01-16 00:00:00 | 2018-12-31 00:00:00 |          18150 |          20300 |               19700 |           100     | False             |
|   2019 |                313 | 2019-01-01 00:00:00 | 2019-12-31 00:00:00 |          19250 |          22350 |               21550 |           100     | False             |
|   2020 |                314 | 2020-01-01 00:00:00 | 2020-12-31 00:00:00 |          21450 |          30300 |               26850 |           119.427 | False             |
|   2021 |                290 | 2021-01-01 00:00:00 | 2021-12-31 00:00:00 |          24500 |          28950 |               28650 |           100     | False             |
|   2022 |                313 | 2022-01-01 00:00:00 | 2022-12-31 00:00:00 |          28300 |          31700 |               29850 |           100     | False             |
|   2023 |                312 | 2023-01-02 00:00:00 | 2023-12-30 00:00:00 |          29650 |          34250 |               33650 |           100     | False             |
|   2024 |                314 | 2024-01-01 00:00:00 | 2024-12-31 00:00:00 |          33450 |          44400 |               42400 |           100     | False             |
|   2025 |                299 | 2025-01-01 00:00:00 | 2025-12-31 00:00:00 |          42650 |          67200 |               64950 |           100     | False             |
|   2026 |                230 | 2026-01-01 00:00:00 | 2026-10-22 00:00:00 |          63050 |          81500 |               65350 |           188.261 | True              |

## Anomalies and limitations
- Nine calendar months are absent from the public mirror (Mar 2013, Aug-Nov 2016, Aug-Nov 2017) plus 1-14 Oct 2026; no imputation is performed - trading and valuation simply skip unavailable days (policy `skip_and_log`).
- 2026 is a partial year (through 22 Oct 2026).
- Quotes are market-wide GTA announcements, not individual shop transactions.